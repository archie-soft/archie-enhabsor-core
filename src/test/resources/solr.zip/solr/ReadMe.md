https://dzone.com/articles/solr-with-scala-basic-introduction-to-embedded-sol

# Setup 

## Install Solr based on setup script in src/setup/docker/config/solr.sh

## Copy files and folders from $BASE/server/solr to this folder
* solr.xml
* server/solr/enhabsor/conf/
* server/solr/enhabsor/core.properties

## Create solr.zip
zip -r solr.zip solr/
